﻿
//carrga dados locacao
$(document).ready(function () {
    CarregaDadosJgo();
});

//Funcao CarregaDados
function CarregaDadosJgo() {
    $.ajax({
        url: "/Home/ListarJgos",
        type: "GET",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            var html = '';
            $.each(result, function (key, item) {
                html += '<tr>';
                html += '<td>' + item.Idjogo + '</td>';
                html += '<td>' + item.Nome + '</td>';
                html += '<td><a href="#"  onclick="return buscaJgoPorId(' + item.Idjogo + ')">Editar</a> | <a href="#" onclick="DeletarJgo(' + item.Nome + ')">Deletar</a></td>';
                html += '</tr>';
            });
            $('.tbody').html(html);
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}


//Add novo jogo
function AddNovoJgo() {

    var userObj = {

        NomeJogo: $("#ListNomeJgo option:selected").text()
        
    };
    $.ajax({
        url: "/Home/AdicionarJogo",
        data: JSON.stringify(userObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            CarregaDadosJgo();
            $('#ModalAdicionar').modal('hide');
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}


//busca Jogo Por Id
function buscaJgoPorId(JgoId) {
    $('#NomeJgo').css('border-color', 'lightgrey');
    $('#IdJogo').css('border-color', 'lightgrey');
    $.ajax({
        url: "/Home/BuscaJogoPorId/" + JgoId,
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (result) {
            $('#NomeJgoEdit').val(result.IdLocacao);
            $('#IdJogoEdit').val(result.IdLocador);
            $('#modalEditar').modal('show');
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}

//Editar locação

function UpdateJgo() {

    var userObj = {
        IdJogo: $('#IdJogoEdit').val(),
        Nome: $('#NomeJgoEdit').val()
    };
    $.ajax({
        url: "/Home/UpdateJgo",
        data: JSON.stringify(userObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {           
            alert("Dados Atualizados com Sucesso!");
            $('#ModalEditar').modal('hide');
            loadData();
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}

//deletar locação
function DeletarJgo(ID) {
    var ans = confirm("Deseja deletar?");
    if (ans) {
        $.ajax({
            url: "/Home/DeletarJogo/" + ID,
            type: "POST",
            contentType: "application/json;charset=UTF-8",
            dataType: "json",
            success: function (result) {
                loadData();
            },
            error: function (errormessage) {
                alert(errormessage.responseText);
            }
        });
    }
}

