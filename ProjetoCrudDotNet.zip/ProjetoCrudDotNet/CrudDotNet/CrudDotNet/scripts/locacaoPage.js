﻿
//carrga dados locacao
$(document).ready(function () {
    CarregaDadosLoc();
});

//Funcao CarregaDados
function CarregaDadosLoc() {
    $.ajax({
        url: "/Home/ListarLoc",
        type: "GET",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            var html = '';
            $.each(result, function (key, item) {
                html += '<tr>';
                html += '<td>' + item.IdLocacao + '</td>';
                html += '<td>' + item.NomeLocador + '</td>';
                html += '<td>' + item.NomeJogo + '</td>';
                html += '<td>' + item.JgoEmprestado + '</td>';
                html += '<td><a href="#"  onclick="return buscaUserPorId(' + item.IdUsuario + ')">Editar</a> | <a href="#" onclick="Deletar(' + item.IdUsuario + ')">Deletar</a></td>';
                html += '</tr>';
            });
            $('.tbody').html(html);
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}

//Funcao Carrega Dados para list com nomes de locadores
function carregaNomes() {
    $.ajax({
        url: "/Home/ListarUsers",
        type: "GET",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            var my_arr = result;
            var num = my_arr.length;
     
             //nomes dos usuarios
            var selectList = "<select name='nomeLoc'>";
            for (var x = 0; x < num; x++) {
                selectList += "<option " + (" value ='", my_arr[x].IdUsuario) + " '>" + my_arr[x].Nome + "</option>";
            }
            selectList += "</select>";

            $('#ListNomeLoc').html(selectList);
            $('#modalAdicionar').modal('show');
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });

    //Funcao Carrega Dados para list com nomes de jogos

        $.ajax({
            url: "/Home/ListarJgos",
            type: "GET",
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            success: function (result) {
                var my_arr = result;
               var num =  my_arr.length;
                //retorna nomes dos jogos
                var selectList = "<select name='nomeJgos'>";
                for (var x = 0; x < num; x++) {
                    selectList += "<option " + (" value ='", my_arr[x].IdJogo) + " '>" + my_arr[x].Nome + "</option>";
                }
                selectList += "</select>";

                $('#ListNomeJgo').html(selectList);
                $('#modalAdicionar').modal('show');
            },
            error: function (errormessage) {
                alert(errormessage.responseText);
            }
        });
}

//Add nova Locação
function AddNovaLoc() {

    var userObj = {

        NomeJogo: $("#ListNomeJgo option:selected").text(),
        IdJogo: ("#ListNomeJgo").find("option:selected").attr('id'),
        NomeLocador: $("#ListNomeLoc option:selected").text(),
        IdLocacao: $("#ListNomeLoc").val(),
        JgoEmprestado: $('#JgoEmprest').val(),

        
    };
    $.ajax({
        url: "/Home/AdicionarLoc",
        data: JSON.stringify(userObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            CarregaDadosLoc();
            $('#ModalAdicionar').modal('hide');
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}


//busca Locação Por Id
function buscaLocPorId(LocId) {
    $('#IdLocacao').css('border-color', 'lightgrey');
    $('#IdLocador').css('border-color', 'lightgrey');
    $('#IdJogo').css('border-color', 'lightgrey');
    $('#JgoEmprest').css('border-color', 'lightgrey');
    $.ajax({
        url: "/Home/BuscaLocPorId/" + LocId,
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (result) {
            $('#IdLocacaoEdit').val(result.IdLocacao);
            $('#IdLocadorEdit').val(result.IdLocador);
            $('#IdJogoEdit').val(result.IdJogo);
            $('#NomeJgoEdit').val(result.IdJogo);
            $('#NomeLocEdit').val(result.NomeLocador);
            $('#JgoEmprestEdit').val(result.JgoEmprestado);
            $('#modalEditar').modal('show');
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}

//Editar locação

function UpdateLoc() {

    var userObj = {
        IdUsuario: $('#IdUsuarioEditar').val(),
        Nome: $('#NomeEditar').val(),
        Tel: $('#TelEditar').val(),
        Email: $('#EmailEditar').val(),
    };
    $.ajax({
        url: "/Home/UpdateUser",
        data: JSON.stringify(userObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {           
            alert("Dados Atualizados com Sucesso!");
            $('#ModalEditar').modal('hide');
            loadData();
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}

//deletar locação
function DeletarLoc(ID) {
    var ans = confirm("Deseja deletar o usuário?");
    if (ans) {
        $.ajax({
            url: "/Home/DeletarUser/" + ID,
            type: "POST",
            contentType: "application/json;charset=UTF-8",
            dataType: "json",
            success: function (result) {
                loadData();
            },
            error: function (errormessage) {
                alert(errormessage.responseText);
            }
        });
    }
}

