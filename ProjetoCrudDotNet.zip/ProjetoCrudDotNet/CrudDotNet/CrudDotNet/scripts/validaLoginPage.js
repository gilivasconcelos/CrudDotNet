﻿
//Funcao Valida Login
function validaLogin() {

    var userObj = {
        LoginUsuario: $('#Login').val(),
        Senha: $('#Senha').val()
    };

    $.ajax({
        url: "/Home/ValidaSessao",
        data: JSON.stringify(userObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
     //   dataType : "json",
        success: function (result) {
            alert(result);
            $("#ModalLogin").modal("hide");
            window.location.href = "/Home/Inicio";
        },
        error: function (result) {
            try {
                              
                location.href = "/Home/Index";
                
            }
            catch (err) {
                alert("Algo deu errado, tente novamente");
                $("#ModalLogin").modal("hide");
            }
        }
    });

};

