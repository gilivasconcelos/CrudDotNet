﻿
//Load Data in Table when documents is ready
$(document).ready(function () {
    CarregaDadosUser();
});




//Funcao CarregaDados
function CarregaDadosUser() {
    $.ajax({
        url: "/Home/ListarUsers",
        type: "GET",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            var html = '';
            $.each(result, function (key, item) {
                html += '<tr>';
                html += '<td>' + item.IdUsuario + '</td>';
                html += '<td>' + item.Nome + '</td>';
                html += '<td>' + item.Tel + '</td>';
                html += '<td>' + item.Email + '</td>';
                html += '<td><a href="#"  onclick="return buscaUserPorId(' + item.IdUsuario + ')">Editar</a> | <a href="#" onclick="DeletarUsuario(' + item.IdUsuario + ')">Deletar</a></td>';
                html += '</tr>';
            });
            $('.tbody').html(html);
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}

//Add novo Usuario
function AddNovoUser() {
 
    var userObj = {
        Nome: $('#Nome').val(),
        Tel: $('#Tel').val(),
        Email: $('#Email').val(),      
    };
    $.ajax({
        url: "/Home/AdicionarUsers",
        data: JSON.stringify(userObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            CarregaDadosUser();
            $('#ModalAdicionar').modal('hide');
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    
}

//busca usuarioPorId
function buscaUserPorId(UserId) {
    $('#IdUsuario').css('border-color', 'lightgrey');
    $('#Nome').css('border-color', 'lightgrey');
    $('#Tel').css('border-color', 'lightgrey');
    $('#Email').css('border-color', 'lightgrey');
    $.ajax({
        url: "/Home/BuscaUserPorId/" + UserId,
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (result) {
            $('#IdUsuarioEditar').val(result.IdUsuario);
            $('#NomeEditar').val(result.Nome);
            $('#TelEditar').val(result.Tel);
            $('#EmailEditar').val(result.Email);
            $('#modalEditar').modal('show');
          //  $('#btnUpdate').show();
         //   $('#btnAdd').hide();
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}

//Editar usuario

function UpdateUser() {

    var userObj = {
        IdUsuario: $('#IdUsuarioEditar').val(),
        Nome: $('#NomeEditar').val(),
        Tel: $('#TelEditar').val(),
        Email: $('#EmailEditar').val(),
    };
    $.ajax({
        url: "/Home/UpdateUser",
        data: JSON.stringify(userObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {           
            alert("Dados Atualizados com Sucesso!");
            $('#ModalEditar').modal('hide');
            loadData();
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}

//deletar usuario
function DeletarUsuario(ID) {
    var ans = confirm("Deseja deletar o usuário?");
    if (ans) {
        $.ajax({
            url: "/Home/DeletaUser/" + ID,
            type: "POST",
            contentType: "application/json;charset=UTF-8",
            dataType: "json",
            success: function (result) {
                CarregaDadosUser();
            },
            error: function (errormessage) {
                alert(errormessage.responseText);
            }
        });
    };
   
}
