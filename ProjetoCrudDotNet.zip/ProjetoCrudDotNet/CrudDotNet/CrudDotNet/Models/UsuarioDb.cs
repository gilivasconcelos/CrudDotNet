﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Configuration;
using System.Configuration.Provider;


namespace CrudDotNet.Models
{
    public class UsuarioDb
    {
        string conString = ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;

        #region retornaUsuario
        public List<UsuarioModel> ListarUsuarios()
        {

            List<UsuarioModel> List = new List<UsuarioModel>();
            using (SqlConnection con = new SqlConnection(conString))

            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM tb_usuario", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    List.Add(new UsuarioModel
                    {
                        IdUsuario = Convert.ToInt32(dr["id_usuario"]),
                        Nome = dr["nome"].ToString(),
                        Tel = dr["tel"].ToString(),
                        Email = dr["email"].ToString(),
                        Senha = dr["senha"].ToString(),
                        LoginUsuario = dr["loginUsuario"].ToString()

                    });
                }
                return List;

            }
        }
        #endregion

        #region Add Usuario

        public int AddUsuario(UsuarioModel novoUser)
        {
            int i = 0;
            using (SqlConnection con = new SqlConnection(conString))

            {
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO tb_usuario(nome,tel,email,senha,loginUsuario) VALUES (' " +
                   novoUser.Nome + "' , '" +
                   novoUser.Tel + "' , '" +
                   novoUser.Email + "' , '" +
                   novoUser.Senha + "' , '" +
                   novoUser.LoginUsuario + "' ) ; "
                   , con);
                cmd.ExecuteNonQuery();
            }
            return i;
        }

        #endregion

        #region UpdateUsuario

        public int UpdateUsuario(UsuarioModel novoUser)
        {
            int i = 0;

            using (SqlConnection con = new SqlConnection(conString))

            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    " UPDATE tb_usuario SET nome = '" + novoUser.Nome + "' , " +
                    " tel = '" + novoUser.Tel + "' , " +
                    " email = '" + novoUser.Email + "'  " +
                    " where id_usuario = " + novoUser.IdUsuario + " ; "
                   , con);
                cmd.ExecuteNonQuery();
            }
            return i;
        }

        #endregion

        #region DeletarUsuario

        public int DeletarUsuario(int idUser)
        {
            int i = 0;
            using (SqlConnection con = new SqlConnection(conString))

            {
                con.Open();
                SqlCommand cmd = new SqlCommand(" DELETE from tb_usuario where id_usuario = " + idUser + " ; "                  
                   , con);
                cmd.ExecuteNonQuery();
            }
            return i;
        }

        #endregion
    }
}



    