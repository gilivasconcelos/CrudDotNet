﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Configuration;
using System.Configuration.Provider;

namespace CrudDotNet.Models
{
    public class JogoDb
    {
        string conString = ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;

        #region retornaJogo
        public List<JogoModel> ListJogos()
        {

            List<JogoModel> List = new List<JogoModel>();
            using (SqlConnection con = new SqlConnection(conString))

            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM tb_jogo", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    List.Add(new JogoModel
                    {
                        IdJogo = Convert.ToInt32(dr["id_jogo"]),
                        Nome = dr["nome"].ToString()
                    });
                }
                return List;

            }
        }
        #endregion

        #region AddJogo

        public int AddJogo(JogoModel novoJogo)
        {
            int i = 0;
            using (SqlConnection con = new SqlConnection(conString))

            {
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO tb_jogo ( nome ) VALUES (' " + novoJogo.Nome + "' ) ; "
                   , con);
                cmd.ExecuteNonQuery();
            }
            return i;

        }
    
    #endregion


    #region UptadeJogo

    public int UpdateJogo(JogoModel novoJogo)
    {
        int i = 0;
        using (SqlConnection con = new SqlConnection(conString))

        {
            con.Open();
            SqlCommand cmd = new SqlCommand(
                " UPDATE tb_jogo SET nome = '" + novoJogo.Nome + "' , " +
                "' where id_jogo = " + novoJogo.IdJogo + " ; "
               , con);
            cmd.ExecuteNonQuery();
        }
        return i;
    }

    #endregion

    #region DeletarJogo

    public int DeletarJogo( int idJgo)
    {
        int i = 0;
        using (SqlConnection con = new SqlConnection(conString))

        {
            con.Open();
            SqlCommand cmd = new SqlCommand(" DELETE from tb_jogo where id_jogo = " + idJgo + " ; "
               , con);
            cmd.ExecuteNonQuery();
        }
        return i;
    }

    #endregion

}


}
