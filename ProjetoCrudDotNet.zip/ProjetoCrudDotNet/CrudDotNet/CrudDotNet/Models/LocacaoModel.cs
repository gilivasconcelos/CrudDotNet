﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CrudDotNet.Models
{
    public class LocacaoModel
    {
        public int IdLocacao { get; set; }
        public int IdLocador { get; set; }
        public string NomeLocador { get; set; }
        public int IdJogo { get; set; }
        public string NomeJogo { get; set; }
        public string JgoEmprestado { get; set; }
    }
}