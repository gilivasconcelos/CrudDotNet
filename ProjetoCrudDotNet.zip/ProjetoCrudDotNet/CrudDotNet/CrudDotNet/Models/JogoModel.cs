﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CrudDotNet.Models
{
    public class JogoModel
    {
        public int IdJogo { get; set; }
        public string Nome { get; set; }
        public int JogoEmprestado { get; set; }
    }
}