﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace CrudDotNet.Models
{
    public class LocacaoDb
    {
        string conString = ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;

        #region retornaLocacao
        public List<LocacaoModel> ListarLocacao()
        {

            List<LocacaoModel> List = new List<LocacaoModel>();
            using (SqlConnection con = new SqlConnection(conString))

            {
                con.Open();

                //Select composto por 3 inners Joins, busca dados das 3 tabelas
                SqlCommand cmd = new SqlCommand(" select  * from tb_locacao ; ", con);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    List.Add(new LocacaoModel
                    {
                     
                        IdLocacao = Convert.ToInt32(dr["id_locacao"]),
                        IdLocador = Convert.ToInt32(dr["id_locador"]),
                        NomeLocador = dr["nomeLocador"].ToString(),
                        IdJogo = Convert.ToInt32(dr["id_Jogo"]),
                        NomeJogo = dr["nomeJgo"].ToString(),
                        JgoEmprestado = dr["jgoEmprestado"].ToString()


                    });
                }
                var teste = List;
                return List;

            }
        }
        #endregion

        #region AddLocacao

        public int AddLocacao(LocacaoModel novaLocacao)
        {
            int i = 0;
            novaLocacao.JgoEmprestado = "SIM";

            using (SqlConnection con = new SqlConnection(conString))

            {
                con.Open();
                SqlCommand cmd = new SqlCommand(" INSERT INTO tb_locacao ( id_locador, id_jogo, nomeJgo, nomeLocador, JgoEmprestado ) VALUES (  " +
                   novaLocacao.IdLocador + "  ,  " +
                   novaLocacao.IdJogo + "  , ' " +
                   novaLocacao.NomeJogo + " ' , ' " +
                   novaLocacao.NomeLocador + " ' , ' " +
                   novaLocacao.JgoEmprestado + " ' ) ; "
                   , con);
                cmd.ExecuteNonQuery();
            }
            return i;
        }

        #endregion

        #region UptadeLocacao

        public int UpdateLocacao(LocacaoModel novaLocacao)
        {
            int i = 0;
            using (SqlConnection con = new SqlConnection(conString))

            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    " UPDATE tb_locacao SET id_locador = '" + novaLocacao.IdLocador + "' , " +
                    " id_jogo = '" + novaLocacao.IdJogo + "' , " +
                    " jgoEmprestado = '" + novaLocacao.JgoEmprestado + "' , " +
                      " nomeJgo = '" + novaLocacao.NomeJogo + "' , " +
                        " nomeLocador = '" + novaLocacao.NomeLocador + "' , " +
                    " where id_locacao = " + novaLocacao.IdLocacao + " ; "
                   , con);
                cmd.ExecuteNonQuery();
            }
            return i;
        }

        #endregion

        #region DeletarLocacao

        public int DeletarLocacao(int novaLocacao)
        {
            int i = 0;
            using (SqlConnection con = new SqlConnection(conString))

            {
                con.Open();
                SqlCommand cmd = new SqlCommand(" DELETE from tb_locacao where id_locacao = " + novaLocacao + " ; "
                   , con);
                cmd.ExecuteNonQuery();
            }
            return i;
        }

        #endregion
    }
}



