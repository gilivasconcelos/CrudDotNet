﻿using CrudDotNet.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CrudDotNet.Controllers
{
    public class HomeController : Controller
    {
        UsuarioDb dbUser = new UsuarioDb();

        #region views
        // View Home Index
        public ActionResult Index()
        {
            return View();
        }

        //View Tela de Locacao
        public ActionResult Locacao()
        {
            return View();
        }

        //View Tela de Usuarios
        public ActionResult Usuario()
        {
            return View();
        }

        // View Home Index
        public ActionResult Jogo()
        {
            return View();
        }
        //View Tela Inicial apos Logar
        public ActionResult Inicio()
        {

           
            return View();
            /* if (Session["idUsuarioLogado"] != null)
             {
                 return View();
             }
             else
             {
                 return RedirectToAction("Index");
             }*/
        }

        #endregion

        //metodos login
        #region metodosLogin

        //Inicia Sessao de usuario


        [HttpPost]
        public JsonResult ValidaSessaoss(UsuarioModel user )
        {
            string retornoMsg ="";


            if (ModelState.IsValid)
            {

               

                var v = dbUser.ListarUsuarios().Find(x => x.LoginUsuario.Equals(user.LoginUsuario) && x.Senha.Equals(user.Senha));


                if (v != null)
                {
                    //valida se já existe sessão ativa
                    if (Session["idUsuarioLogado"] != null)
                    {

                       
                        retornoMsg = "Você já está logado! Existe uma sessão ativa!";
                    
                    }
                    //cria uma nova sessão
                    else
                    {
                        Session["NomeCompleto"] = v.Nome.ToString();
                        Session["idUsuarioLogado"] = v.IdUsuario.ToString();
                       
                        retornoMsg = "Logado com Sucesso!";
                    }

                     return  Json(retornoMsg, JsonRequestBehavior.AllowGet);
                }
                //Login ou Senha Invalidos ao tentar abrir sessao
                else
                {
                    
                    retornoMsg = "Login ou Senha inválido";
                    return Json(retornoMsg, JsonRequestBehavior.AllowGet);
                }

            }
                return Json(RedirectToAction("Index"), JsonRequestBehavior.AllowGet);
            

        }

        [HttpPost]
        public ActionResult ValidaSessao(UsuarioModel user)
        {
            

                var retornoLogin = "";

                var v = dbUser.ListarUsuarios().Find(x => x.LoginUsuario.Equals(user.LoginUsuario) && x.Senha.Equals(user.Senha));
                   

                if (v != null)
                {
                    //valida se já existe sessão ativa
                    if (Session["idUsuarioLogado"] != null)
                    {

                        retornoLogin = "Você já está logado! Já existe uma sessão ativa!";
                        return Json(retornoLogin, JsonRequestBehavior.AllowGet);
                    }
                    //cria uma nova sessão
                    else
                    {
                        Session["NomeCompleto"] = v.Nome.ToString();
                        Session["idUsuarioLogado"] = v.IdUsuario.ToString();                      
                        retornoLogin = "Logado com Sucesso!";
                    }

                //  return Json(retornoLogin, JsonRequestBehavior.AllowGet);

                return RedirectToAction("Inicio");

            }
            //Login ou Senha Invalidos ao tentar abrir sessao
            else
                {
                    
                    retornoLogin = "Login ou Senha inválido";
                    return Json(retornoLogin, JsonRequestBehavior.AllowGet);
                }


            //  return Json(RedirectToAction("Index"), JsonRequestBehavior.AllowGet);

            return RedirectToAction("Inicio");

        }



        //Finaliza sessao
        public JsonResult Sair()
        {
                Session.Remove("idUsuarioLogado");
                Session.Remove("NomeCompleto");
                Response.Redirect("Index");
                return Json(RedirectToAction("Index"), JsonRequestBehavior.AllowGet);
        
        }
        #endregion

        //Metodos Locação
        #region metodosLocacao

        LocacaoDb dbLocacao = new LocacaoDb();

        public JsonResult ListarLoc()
        {
            return Json(dbLocacao.ListarLocacao(), JsonRequestBehavior.AllowGet);
        }

        public JsonResult AdicionarLoc(LocacaoModel novaLocacao)
        {
            return Json(dbLocacao.AddLocacao(novaLocacao), JsonRequestBehavior.AllowGet);
        }

        public JsonResult BuscaLocPorId(int ID)
        {
            var VarLocacao = dbLocacao.ListarLocacao().Find(x => x.IdJogo.Equals(ID));
            return Json(VarLocacao, JsonRequestBehavior.AllowGet); ;
        }

        public JsonResult UpdateLocacao(LocacaoModel novaLocacao)
        {
            return Json(dbLocacao.UpdateLocacao(novaLocacao), JsonRequestBehavior.AllowGet);

        }

        public JsonResult DeletarLocacao(int id)
        {
            return Json(dbUser.DeletarUsuario(id), JsonRequestBehavior.AllowGet);

        }
        #endregion

        //metodos Usuario
        #region metodosUsuario
        public JsonResult ListarUsers()
        {
            return Json(dbUser.ListarUsuarios(), JsonRequestBehavior.AllowGet);
        }

        public JsonResult AdicionarUsers(UsuarioModel usuario)
        {
            return Json(dbUser.AddUsuario(usuario), JsonRequestBehavior.AllowGet);
        }

        public JsonResult BuscaUserPorId(int ID)
        {
            var VarUsuario = dbUser.ListarUsuarios().Find(x => x.IdUsuario.Equals(ID));
            return Json(VarUsuario, JsonRequestBehavior.AllowGet); ;
        }

         public JsonResult UpdateUser(UsuarioModel usuario)
          {
            return Json(dbUser.UpdateUsuario(usuario), JsonRequestBehavior.AllowGet);

          }

          public JsonResult DeletaUser(int id)
          {
            return Json(dbUser.DeletarUsuario(id), JsonRequestBehavior.AllowGet);

          }

        #endregion

        //Metodos Jogo
        #region MetodosJogo


        JogoDb dbJogo = new JogoDb();
     
        public JsonResult ListarJgos()
        {
            return Json(dbJogo.ListJogos(), JsonRequestBehavior.AllowGet);
        }

        public JsonResult AdicionarJogo(JogoModel novoJogo)
        {
            return Json(dbJogo.AddJogo(novoJogo), JsonRequestBehavior.AllowGet);
        }

        public JsonResult BuscaJogoPorId(int ID)
        {
            var VarJogo = dbJogo.ListJogos().Find(x => x.IdJogo.Equals(ID));
            return Json(VarJogo, JsonRequestBehavior.AllowGet); ;
        }

        public JsonResult UpdateJgo(JogoModel novoJgo)
        {
            return Json(dbJogo.UpdateJogo(novoJgo), JsonRequestBehavior.AllowGet);

        }

        public JsonResult DeletarJogo(int idJogo)
        {
            return Json(dbJogo.DeletarJogo( idJogo), JsonRequestBehavior.AllowGet);

        }
        #endregion

    }
}